"""Parameters for ccc_gistemp.
"""
from . standard import *
from . obsolete import *
from . extensions import *


