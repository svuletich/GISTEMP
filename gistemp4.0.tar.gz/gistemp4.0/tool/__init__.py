"""The CCC tool package.
"""
